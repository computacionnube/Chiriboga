﻿namespace Compra_de_Autos
{
    partial class Autos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Autos));
            this.dgvD = new System.Windows.Forms.DataGridView();
            this.Modelos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Motors = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Años = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Precios = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Condicions = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Recorridos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ultimo_Digito_de_la_Placa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Combustible = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sistema_de_Climatizacion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Vidrios = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Direccion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Placa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Numero_de_Propietarios = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tapizado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblmen = new System.Windows.Forms.Label();
            this.lisAutos = new System.Windows.Forms.ImageList(this.components);
            this.btnVender = new System.Windows.Forms.Button();
            this.PicAutos = new System.Windows.Forms.PictureBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.compraDeAutosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registroDeVentasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.dgvD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicAutos)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvD
            // 
            this.dgvD.AllowUserToAddRows = false;
            this.dgvD.AllowUserToDeleteRows = false;
            this.dgvD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvD.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Modelos,
            this.Motors,
            this.Años,
            this.Precios,
            this.Condicions,
            this.Recorridos,
            this.Ultimo_Digito_de_la_Placa,
            this.Combustible,
            this.Sistema_de_Climatizacion,
            this.Vidrios,
            this.Direccion,
            this.Placa,
            this.Numero_de_Propietarios,
            this.Tapizado});
            this.dgvD.Location = new System.Drawing.Point(0, 248);
            this.dgvD.Name = "dgvD";
            this.dgvD.ReadOnly = true;
            this.dgvD.Size = new System.Drawing.Size(860, 278);
            this.dgvD.TabIndex = 2;
            this.dgvD.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvD_CellClick);
            // 
            // Modelos
            // 
            this.Modelos.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Modelos.HeaderText = "Modelo";
            this.Modelos.Name = "Modelos";
            this.Modelos.ReadOnly = true;
            this.Modelos.Width = 67;
            // 
            // Motors
            // 
            this.Motors.HeaderText = "Motor";
            this.Motors.Name = "Motors";
            this.Motors.ReadOnly = true;
            // 
            // Años
            // 
            this.Años.HeaderText = "Año";
            this.Años.Name = "Años";
            this.Años.ReadOnly = true;
            // 
            // Precios
            // 
            this.Precios.HeaderText = "Precio";
            this.Precios.Name = "Precios";
            this.Precios.ReadOnly = true;
            // 
            // Condicions
            // 
            this.Condicions.HeaderText = "Condicion";
            this.Condicions.Name = "Condicions";
            this.Condicions.ReadOnly = true;
            // 
            // Recorridos
            // 
            this.Recorridos.HeaderText = "Recorrido";
            this.Recorridos.Name = "Recorridos";
            this.Recorridos.ReadOnly = true;
            // 
            // Ultimo_Digito_de_la_Placa
            // 
            this.Ultimo_Digito_de_la_Placa.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Ultimo_Digito_de_la_Placa.HeaderText = "Ultimo_Digito_de_la_Placa";
            this.Ultimo_Digito_de_la_Placa.Name = "Ultimo_Digito_de_la_Placa";
            this.Ultimo_Digito_de_la_Placa.ReadOnly = true;
            this.Ultimo_Digito_de_la_Placa.Width = 159;
            // 
            // Combustible
            // 
            this.Combustible.HeaderText = "Combustible";
            this.Combustible.Name = "Combustible";
            this.Combustible.ReadOnly = true;
            // 
            // Sistema_de_Climatizacion
            // 
            this.Sistema_de_Climatizacion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Sistema_de_Climatizacion.HeaderText = "Sistema_de_Climatizacion";
            this.Sistema_de_Climatizacion.Name = "Sistema_de_Climatizacion";
            this.Sistema_de_Climatizacion.ReadOnly = true;
            this.Sistema_de_Climatizacion.Width = 154;
            // 
            // Vidrios
            // 
            this.Vidrios.HeaderText = "Vidrios";
            this.Vidrios.Name = "Vidrios";
            this.Vidrios.ReadOnly = true;
            // 
            // Direccion
            // 
            this.Direccion.HeaderText = "Direccion";
            this.Direccion.Name = "Direccion";
            this.Direccion.ReadOnly = true;
            // 
            // Placa
            // 
            this.Placa.HeaderText = "Placa";
            this.Placa.Name = "Placa";
            this.Placa.ReadOnly = true;
            // 
            // Numero_de_Propietarios
            // 
            this.Numero_de_Propietarios.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Numero_de_Propietarios.HeaderText = "Numero_de_Propietarios";
            this.Numero_de_Propietarios.Name = "Numero_de_Propietarios";
            this.Numero_de_Propietarios.ReadOnly = true;
            this.Numero_de_Propietarios.Width = 148;
            // 
            // Tapizado
            // 
            this.Tapizado.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Tapizado.HeaderText = "Tapizado";
            this.Tapizado.Name = "Tapizado";
            this.Tapizado.ReadOnly = true;
            this.Tapizado.Width = 76;
            // 
            // lblmen
            // 
            this.lblmen.BackColor = System.Drawing.Color.Transparent;
            this.lblmen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmen.ForeColor = System.Drawing.Color.White;
            this.lblmen.Location = new System.Drawing.Point(252, 28);
            this.lblmen.Name = "lblmen";
            this.lblmen.Size = new System.Drawing.Size(310, 217);
            this.lblmen.TabIndex = 4;
            // 
            // lisAutos
            // 
            this.lisAutos.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("lisAutos.ImageStream")));
            this.lisAutos.TransparentColor = System.Drawing.Color.Transparent;
            this.lisAutos.Images.SetKeyName(0, "chevrolet_grand_vitara_2015_chevrolet_grand_vitara_3p_2015_7910121535724926515.jp" +
        "g");
            this.lisAutos.Images.SetKeyName(1, "2018-aveo-family-vino-07.jpg");
            this.lisAutos.Images.SetKeyName(2, "f688658500aac388494bc4ed1826516c.jpg");
            this.lisAutos.Images.SetKeyName(3, "788762_1510256251_164.jpg");
            this.lisAutos.Images.SetKeyName(4, "450_1000.jpg");
            this.lisAutos.Images.SetKeyName(5, "0439_nissan_nuevax-trail_5__2.jpg");
            this.lisAutos.Images.SetKeyName(6, "P_027e0b1e182d4873891e3d37b99dfc1c.jpg");
            this.lisAutos.Images.SetKeyName(7, "71g47zLSX5L._UY560_.jpg");
            this.lisAutos.Images.SetKeyName(8, "VA_42c7851e4e6c42fd80ea44dd28be5621.jpg");
            this.lisAutos.Images.SetKeyName(9, "halogenos-neblineros-toyota-yaris-nitro-2009-2011-D_NQ_NP_267311-MEC20549312730_0" +
        "12016-Q.jpg");
            // 
            // btnVender
            // 
            this.btnVender.BackgroundImage = global::Compra_de_Autos.Properties.Resources.buyacar_89124;
            this.btnVender.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnVender.Enabled = false;
            this.btnVender.Location = new System.Drawing.Point(610, 48);
            this.btnVender.Name = "btnVender";
            this.btnVender.Size = new System.Drawing.Size(50, 50);
            this.btnVender.TabIndex = 7;
            this.toolTip1.SetToolTip(this.btnVender, "Vender Auto");
            this.btnVender.UseVisualStyleBackColor = true;
            this.btnVender.Click += new System.EventHandler(this.button1_Click);
            // 
            // PicAutos
            // 
            this.PicAutos.Location = new System.Drawing.Point(0, 27);
            this.PicAutos.Name = "PicAutos";
            this.PicAutos.Size = new System.Drawing.Size(246, 195);
            this.PicAutos.TabIndex = 3;
            this.PicAutos.TabStop = false;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1,
            this.toolStripButton2,
            this.toolStripButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(860, 25);
            this.toolStrip1.TabIndex = 8;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.compraDeAutosToolStripMenuItem,
            this.registroDeVentasToolStripMenuItem});
            this.toolStripDropDownButton1.Image = global::Compra_de_Autos.Properties.Resources.homepage_80953;
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(29, 22);
            this.toolStripDropDownButton1.Text = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.ToolTipText = "Inicio";
            // 
            // compraDeAutosToolStripMenuItem
            // 
            this.compraDeAutosToolStripMenuItem.Image = global::Compra_de_Autos.Properties.Resources._1490129319_rounded09_82169;
            this.compraDeAutosToolStripMenuItem.Name = "compraDeAutosToolStripMenuItem";
            this.compraDeAutosToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.compraDeAutosToolStripMenuItem.Text = "Compra de Autos";
            this.compraDeAutosToolStripMenuItem.Click += new System.EventHandler(this.compraDeAutosToolStripMenuItem_Click);
            // 
            // registroDeVentasToolStripMenuItem
            // 
            this.registroDeVentasToolStripMenuItem.Image = global::Compra_de_Autos.Properties.Resources._1492532806_2_cash_register_83230;
            this.registroDeVentasToolStripMenuItem.Name = "registroDeVentasToolStripMenuItem";
            this.registroDeVentasToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.registroDeVentasToolStripMenuItem.Text = "Registro de Ventas";
            this.registroDeVentasToolStripMenuItem.Click += new System.EventHandler(this.registroDeVentasToolStripMenuItem_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = global::Compra_de_Autos.Properties.Resources.logout_90894;
            this.toolStripButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(49, 22);
            this.toolStripButton1.Text = "Salir";
            this.toolStripButton1.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.toolStripButton1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(64, 22);
            this.toolStripButton2.Text = "Minimizar";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // Autos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = global::Compra_de_Autos.Properties.Resources.audi_r8_gt_1920x1080;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(860, 529);
            this.ControlBox = false;
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.btnVender);
            this.Controls.Add(this.lblmen);
            this.Controls.Add(this.PicAutos);
            this.Controls.Add(this.dgvD);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Autos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Autos";
            ((System.ComponentModel.ISupportInitialize)(this.dgvD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicAutos)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblmen;
        private System.Windows.Forms.PictureBox PicAutos;
        private System.Windows.Forms.ImageList lisAutos;
        private System.Windows.Forms.Button btnVender;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem compraDeAutosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registroDeVentasToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolTip toolTip1;
        public System.Windows.Forms.DataGridView dgvD;
        private System.Windows.Forms.DataGridViewTextBoxColumn Modelos;
        private System.Windows.Forms.DataGridViewTextBoxColumn Motors;
        private System.Windows.Forms.DataGridViewTextBoxColumn Años;
        private System.Windows.Forms.DataGridViewTextBoxColumn Precios;
        private System.Windows.Forms.DataGridViewTextBoxColumn Condicions;
        private System.Windows.Forms.DataGridViewTextBoxColumn Recorridos;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ultimo_Digito_de_la_Placa;
        private System.Windows.Forms.DataGridViewTextBoxColumn Combustible;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sistema_de_Climatizacion;
        private System.Windows.Forms.DataGridViewTextBoxColumn Vidrios;
        private System.Windows.Forms.DataGridViewTextBoxColumn Direccion;
        private System.Windows.Forms.DataGridViewTextBoxColumn Placa;
        private System.Windows.Forms.DataGridViewTextBoxColumn Numero_de_Propietarios;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tapizado;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
    }
}