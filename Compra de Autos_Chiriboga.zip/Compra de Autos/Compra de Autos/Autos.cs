﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Compra_de_Autos
{
    public partial class Autos : Form
    {
        
        
      
        PictureBox ima = new PictureBox();
        public Autos()
        {
            InitializeComponent();
            dgvD.Rows.Add("Chevrolet Grand Vitara 3P", "1600", "2006", "12.000", "USADO", "147000 km","3","Gasolina","Aire Acondicionado","Automatico","Hidraulica","Pichincha","2","Tela");
            dgvD.Rows.Add("Chevrolet Aveo Family", "1500", "2014", "11.700", "USADO", "600000 km", "6","Gasolina","Aire Acondicionado","Manual","Electronica","Loja","1","Cuero");
            dgvD.Rows.Add("Ford Ecosport", "3500", "2006", "9.700", "USADO", "190000 km", "4", "Gasolina", "Aire Acondicionado", "Automaticos", "Hidraulica", "Imbabura", "3", "Cuero");
            dgvD.Rows.Add("Hyudai Tucson IX", "2000", "2011", "20.500", "USADO", "158000 km","1","Gasolina", "Aire Acondicionado", "Automaticos","Electronica","Loja","2","Tela");
            dgvD.Rows.Add("Kia Sportage Rresumen", "2500", "2011", "22.000", "USADO", "182816 km","3","Gasolina","Aire Acondicionado","Manual","Hidraulica","Pichincha","1","Cuero");
            dgvD.Rows.Add("Nissan Xatrail Advance", "5400", "2019", "40.000", "NUEVO", "0 km","2", "Gasolina", "Aire Acondicionado", "Automatica", "Hidraulica", "Pichincha", "0", "Tela");
            dgvD.Rows.Add("Nissan Xtrail Classic", "5400", "2007", "14.500", "USADO", "200000 km", "1", "Gasolina", "Aire Acondicionado", "Automatica", "Electronica", "Loja", "2", "Cuero");
            dgvD.Rows.Add("Suziki Gran VirataSz", "2000", "2015", "17.500", "USADO", "930000 km", "4", "Gasolina", "Aire Acondicionado", "Automaticos", "Hidraulica", "Imbabura", "3", "Cuero");
            dgvD.Rows.Add("Toyota Hilux CD 4X2", "2700", "2019", "30.000", "NUEVO", "0 km", "3", "Gasolina", "Aire Acondicionado", "Manual", "Hidraulica", "Cuenca", "0", "Tela");
            dgvD.Rows.Add("Toyota Yaris Nitro", "1500", "2019", "19.500", "USADO", "17000 km", "2", "Gasolina", "Aire Acondicionado", "Automatica", "Hidraulica", "Pichincha", "0", "Tela");
        }
        int pos = 0;
        double valorau = 0;
        private void dgvD_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            btnVender.Enabled = true;
            pos = dgvD.CurrentRow.Index;
            lblmen.Text = "Modelo: " + Convert.ToString(dgvD[0, pos].Value);
            lblmen.Text += "\nMotor: " + Convert.ToString(dgvD[1, pos].Value);
            lblmen.Text += "\nAño: " + Convert.ToInt32(dgvD[2, pos].Value);
            lblmen.Text += "\nPrecio: " + Convert.ToDouble(dgvD[3, pos].Value);
            lblmen.Text += "\nCondicion: " + Convert.ToString(dgvD[4, pos].Value);
            lblmen.Text += "\nRecorrido: " + Convert.ToString(dgvD[5, pos].Value);
            lblmen.Text += "\nUltimo Digito de la Placa: " + Convert.ToString(dgvD[6, pos].Value);
            lblmen.Text += "\nCombustible: " + Convert.ToString(dgvD[7, pos].Value);
            lblmen.Text += "\nSistema de Climatisacion: " + Convert.ToString(dgvD[8, pos].Value);
            lblmen.Text += "\nVidrios: " + Convert.ToString(dgvD[9, pos].Value);
            lblmen.Text += "\nDireccion: " + Convert.ToString(dgvD[10, pos].Value);
            lblmen.Text += "\nPlaca: " + Convert.ToString(dgvD[11, pos].Value);
            lblmen.Text += "\nNumero de Propietarios: " + Convert.ToString(dgvD[12, pos].Value);
            lblmen.Text += "\nTapizado: " + Convert.ToString(dgvD[13, pos].Value);
            valorau = Convert.ToDouble(dgvD[3, pos].Value);
            PicAutos.Image = lisAutos.Images[pos];
            ima.Image= lisAutos.Images[pos];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Venta ven = new Venta();
            ven.picA.Image = ima.Image;
            ven.lblDatos.Text = lblmen.Text;
            ven.preau = valorau;
            ven.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void compraDeAutosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Compra com = new Compra();
            com.ShowDialog();
        }

        private void registroDeVentasToolStripMenuItem_Click(object sender, EventArgs e)
        {

            RegistroVenta re = new RegistroVenta();
            re.Visible = true;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }
    }
}
