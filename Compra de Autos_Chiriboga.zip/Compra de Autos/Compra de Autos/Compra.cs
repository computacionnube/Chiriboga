﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Compra_de_Autos
{
    public partial class Compra : Form
    {
        public Compra()
        {
            InitializeComponent();
        }

        private void btnImagen_Click(object sender, EventArgs e)
        {
            OpenFileDialog Imagen = new OpenFileDialog();
            Imagen.InitialDirectory = "C:\\";
            Imagen.Filter = "Archivos de imagen (*.jpg)(jpeg)|*.jpg;*.jpeg|PNG(*.png)|*.png";
            if (Imagen.ShowDialog() == DialogResult.OK)
            {
                Foto.ImageLocation = Imagen.FileName;

            }
            else
            {
                MessageBox.Show("No tiene ninguna imagen seleccionada seguro que desea salir", "Mensaje", MessageBoxButtons.OK);
            }
        }

        private void btnComprar_Click(object sender, EventArgs e)
        {

        }
    }
}
