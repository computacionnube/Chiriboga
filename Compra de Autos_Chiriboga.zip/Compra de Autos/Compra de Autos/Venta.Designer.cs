﻿namespace Compra_de_Autos
{
    partial class Venta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDatos = new System.Windows.Forms.Label();
            this.picA = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbPlasos = new System.Windows.Forms.RadioButton();
            this.rdbContado = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCedulaPla = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtNombrePla = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.btnVenderPla = new System.Windows.Forms.Button();
            this.btnCalcularPla = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblMensual = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblValorPla = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.nudMeses = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.nudAños = new System.Windows.Forms.NumericUpDown();
            this.txtEntrada = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lblCambio = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblValorCon = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtCedulaCon = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtNombreCon = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.btnVenderCon = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDineroCon = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picA)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudMeses)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAños)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblDatos
            // 
            this.lblDatos.BackColor = System.Drawing.Color.Transparent;
            this.lblDatos.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatos.ForeColor = System.Drawing.Color.White;
            this.lblDatos.Location = new System.Drawing.Point(916, 9);
            this.lblDatos.Name = "lblDatos";
            this.lblDatos.Size = new System.Drawing.Size(295, 440);
            this.lblDatos.TabIndex = 0;
            // 
            // picA
            // 
            this.picA.Location = new System.Drawing.Point(610, 12);
            this.picA.Name = "picA";
            this.picA.Size = new System.Drawing.Size(246, 195);
            this.picA.TabIndex = 2;
            this.picA.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.rdbPlasos);
            this.groupBox1.Controls.Add(this.rdbContado);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(281, 76);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 75);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Formas de Pago";
            // 
            // rdbPlasos
            // 
            this.rdbPlasos.AutoSize = true;
            this.rdbPlasos.Location = new System.Drawing.Point(17, 49);
            this.rdbPlasos.Name = "rdbPlasos";
            this.rdbPlasos.Size = new System.Drawing.Size(88, 20);
            this.rdbPlasos.TabIndex = 1;
            this.rdbPlasos.TabStop = true;
            this.rdbPlasos.Text = "A Plasos";
            this.rdbPlasos.UseVisualStyleBackColor = true;
            this.rdbPlasos.CheckedChanged += new System.EventHandler(this.rdbPlasos_CheckedChanged);
            // 
            // rdbContado
            // 
            this.rdbContado.AutoSize = true;
            this.rdbContado.Location = new System.Drawing.Point(17, 22);
            this.rdbContado.Name = "rdbContado";
            this.rdbContado.Size = new System.Drawing.Size(100, 20);
            this.rdbContado.TabIndex = 0;
            this.rdbContado.TabStop = true;
            this.rdbContado.Text = "Al contado";
            this.rdbContado.UseVisualStyleBackColor = true;
            this.rdbContado.CheckedChanged += new System.EventHandler(this.rdbContado_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.txtCedulaPla);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.txtNombrePla);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.btnVenderPla);
            this.groupBox2.Controls.Add(this.btnCalcularPla);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.lblMensual);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.lblValorPla);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.nudMeses);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.nudAños);
            this.groupBox2.Controls.Add(this.txtEntrada);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Enabled = false;
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(12, 195);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(437, 241);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "A Plasos";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(254, 177);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 52);
            this.label6.TabIndex = 20;
            this.label6.Text = "Valor Minimo de Entrada 2000";
            // 
            // txtCedulaPla
            // 
            this.txtCedulaPla.Location = new System.Drawing.Point(235, 111);
            this.txtCedulaPla.Name = "txtCedulaPla";
            this.txtCedulaPla.Size = new System.Drawing.Size(170, 24);
            this.txtCedulaPla.TabIndex = 19;
            this.txtCedulaPla.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCedulaPla_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(232, 88);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(183, 18);
            this.label12.TabIndex = 18;
            this.label12.Text = "Cedula del Comprardor";
            // 
            // txtNombrePla
            // 
            this.txtNombrePla.Location = new System.Drawing.Point(235, 52);
            this.txtNombrePla.Name = "txtNombrePla";
            this.txtNombrePla.Size = new System.Drawing.Size(170, 24);
            this.txtNombrePla.TabIndex = 17;
            this.txtNombrePla.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNombrePla_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(232, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(191, 18);
            this.label11.TabIndex = 16;
            this.label11.Text = "Nombre del Comprardor";
            // 
            // btnVenderPla
            // 
            this.btnVenderPla.Enabled = false;
            this.btnVenderPla.ForeColor = System.Drawing.Color.Black;
            this.btnVenderPla.Location = new System.Drawing.Point(102, 137);
            this.btnVenderPla.Name = "btnVenderPla";
            this.btnVenderPla.Size = new System.Drawing.Size(84, 27);
            this.btnVenderPla.TabIndex = 15;
            this.btnVenderPla.Text = "Vender";
            this.btnVenderPla.UseVisualStyleBackColor = true;
            this.btnVenderPla.Click += new System.EventHandler(this.btnVenderPla_Click);
            // 
            // btnCalcularPla
            // 
            this.btnCalcularPla.ForeColor = System.Drawing.Color.Black;
            this.btnCalcularPla.Location = new System.Drawing.Point(9, 137);
            this.btnCalcularPla.Name = "btnCalcularPla";
            this.btnCalcularPla.Size = new System.Drawing.Size(87, 27);
            this.btnCalcularPla.TabIndex = 14;
            this.btnCalcularPla.Text = "Calcular";
            this.btnCalcularPla.UseVisualStyleBackColor = true;
            this.btnCalcularPla.Click += new System.EventHandler(this.btnCalcularPla_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(160, 111);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 18);
            this.label10.TabIndex = 13;
            this.label10.Text = "15%";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(148, 88);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 18);
            this.label9.TabIndex = 12;
            this.label9.Text = "Interes";
            // 
            // lblMensual
            // 
            this.lblMensual.AutoSize = true;
            this.lblMensual.Location = new System.Drawing.Point(156, 211);
            this.lblMensual.Name = "lblMensual";
            this.lblMensual.Size = new System.Drawing.Size(28, 18);
            this.lblMensual.TabIndex = 11;
            this.lblMensual.Text = "....";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 211);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 18);
            this.label7.TabIndex = 10;
            this.label7.Text = "Letra Mensual:";
            // 
            // lblValorPla
            // 
            this.lblValorPla.AutoSize = true;
            this.lblValorPla.Location = new System.Drawing.Point(156, 180);
            this.lblValorPla.Name = "lblValorPla";
            this.lblValorPla.Size = new System.Drawing.Size(28, 18);
            this.lblValorPla.TabIndex = 9;
            this.lblValorPla.Text = "....";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 180);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(118, 18);
            this.label5.TabIndex = 8;
            this.label5.Text = "Valor del Auto:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(78, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 18);
            this.label4.TabIndex = 7;
            this.label4.Text = "Meses";
            // 
            // nudMeses
            // 
            this.nudMeses.Location = new System.Drawing.Point(81, 109);
            this.nudMeses.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.nudMeses.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudMeses.Name = "nudMeses";
            this.nudMeses.Size = new System.Drawing.Size(46, 24);
            this.nudMeses.TabIndex = 6;
            this.nudMeses.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "Años";
            // 
            // nudAños
            // 
            this.nudAños.Location = new System.Drawing.Point(17, 109);
            this.nudAños.Name = "nudAños";
            this.nudAños.Size = new System.Drawing.Size(46, 24);
            this.nudAños.TabIndex = 4;
            // 
            // txtEntrada
            // 
            this.txtEntrada.Location = new System.Drawing.Point(17, 52);
            this.txtEntrada.Name = "txtEntrada";
            this.txtEntrada.Size = new System.Drawing.Size(170, 24);
            this.txtEntrada.TabIndex = 3;
            this.txtEntrada.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEntrada_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(222, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Ingrese el Dinero de Entrada";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.lblCambio);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.lblValorCon);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.txtCedulaCon);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.txtNombreCon);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.btnVenderCon);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.txtDineroCon);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.White;
            this.groupBox3.Location = new System.Drawing.Point(466, 209);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(390, 184);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Al Contado";
            // 
            // lblCambio
            // 
            this.lblCambio.AutoSize = true;
            this.lblCambio.Location = new System.Drawing.Point(281, 146);
            this.lblCambio.Name = "lblCambio";
            this.lblCambio.Size = new System.Drawing.Size(28, 18);
            this.lblCambio.TabIndex = 27;
            this.lblCambio.Text = "....";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(193, 146);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(66, 18);
            this.label15.TabIndex = 26;
            this.label15.Text = "Cambio";
            // 
            // lblValorCon
            // 
            this.lblValorCon.AutoSize = true;
            this.lblValorCon.Location = new System.Drawing.Point(148, 146);
            this.lblValorCon.Name = "lblValorCon";
            this.lblValorCon.Size = new System.Drawing.Size(28, 18);
            this.lblValorCon.TabIndex = 25;
            this.lblValorCon.Text = "....";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(18, 146);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(118, 18);
            this.label18.TabIndex = 24;
            this.label18.Text = "Valor del Auto:";
            // 
            // txtCedulaCon
            // 
            this.txtCedulaCon.Location = new System.Drawing.Point(196, 111);
            this.txtCedulaCon.Name = "txtCedulaCon";
            this.txtCedulaCon.Size = new System.Drawing.Size(170, 24);
            this.txtCedulaCon.TabIndex = 23;
            this.txtCedulaCon.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCedulaPla_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(193, 88);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(183, 18);
            this.label13.TabIndex = 22;
            this.label13.Text = "Cedula del Comprardor";
            // 
            // txtNombreCon
            // 
            this.txtNombreCon.Location = new System.Drawing.Point(196, 52);
            this.txtNombreCon.Name = "txtNombreCon";
            this.txtNombreCon.Size = new System.Drawing.Size(170, 24);
            this.txtNombreCon.TabIndex = 21;
            this.txtNombreCon.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNombrePla_KeyPress);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(193, 20);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(191, 18);
            this.label14.TabIndex = 20;
            this.label14.Text = "Nombre del Comprardor";
            // 
            // btnVenderCon
            // 
            this.btnVenderCon.ForeColor = System.Drawing.Color.Black;
            this.btnVenderCon.Location = new System.Drawing.Point(40, 110);
            this.btnVenderCon.Name = "btnVenderCon";
            this.btnVenderCon.Size = new System.Drawing.Size(84, 27);
            this.btnVenderCon.TabIndex = 2;
            this.btnVenderCon.Text = "Vender";
            this.btnVenderCon.UseVisualStyleBackColor = true;
            this.btnVenderCon.Click += new System.EventHandler(this.btnVenderCon_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ingrese el Dinero";
            // 
            // txtDineroCon
            // 
            this.txtDineroCon.Location = new System.Drawing.Point(6, 52);
            this.txtDineroCon.Name = "txtDineroCon";
            this.txtDineroCon.Size = new System.Drawing.Size(170, 24);
            this.txtDineroCon.TabIndex = 0;
            this.txtDineroCon.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEntrada_KeyPress);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(32, 125);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Cancelar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Venta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Compra_de_Autos.Properties.Resources.B__21_;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1234, 511);
            this.ControlBox = false;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.picA);
            this.Controls.Add(this.lblDatos);
            this.Name = "Venta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "VENTA";
            ((System.ComponentModel.ISupportInitialize)(this.picA)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudMeses)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAños)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        public System.Windows.Forms.Label lblDatos;
        public System.Windows.Forms.PictureBox picA;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbPlasos;
        private System.Windows.Forms.RadioButton rdbContado;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblValorPla;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nudMeses;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nudAños;
        private System.Windows.Forms.TextBox txtEntrada;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnVenderCon;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDineroCon;
        private System.Windows.Forms.Button btnVenderPla;
        private System.Windows.Forms.Button btnCalcularPla;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblMensual;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtCedulaPla;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtNombrePla;
        private System.Windows.Forms.Label lblValorCon;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtCedulaCon;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtNombreCon;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblCambio;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button1;
    }
}