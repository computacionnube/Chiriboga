﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Compra_de_Autos
{
    public partial class Venta : Form
    {
        RegistroVenta regis = new RegistroVenta();
        Autos a = new Autos();
        public Venta()
        {
            InitializeComponent();

        }
        int meses1;
        int meses2;
        double entrada = 0;
        double mensual = 0;
        double iva;
        public double preau = 0;
        double t = 0;
        double total = 0;
        double preciotal = 0;
        double carropre = 0;
        private void btnCalcularPla_Click(object sender, EventArgs e)
        {
            entrada =Convert.ToDouble(txtEntrada.Text);
            if (entrada>=2000)
            {
                meses1 = Convert.ToInt32(nudAños.Value) * 12;
                meses2 = meses1 + Convert.ToInt32(nudMeses.Value);
                t = preau - entrada;
                mensual = t / meses2;
                iva = mensual * 0.15;
                total = mensual + iva;
                lblMensual.Text = total.ToString();
                preciotal = (total * meses2)+entrada;
                lblValorPla.Text = preciotal.ToString();
                btnVenderPla.Enabled = true;

            }
            else
            {
                MessageBox.Show("Dinero Insuficiente", "Plasos");
            }
        }

        private void rdbContado_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbPlasos.Checked == true)
            {
                groupBox2.Enabled = true;
            }
            else
            {
                groupBox2.Enabled = false;
            }
            
        }

        private void rdbPlasos_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbContado.Checked==true)
            {
                groupBox3.Enabled = true;
            }
            else
            {
                groupBox3.Enabled = false;
            }
                    
        }

        private void btnVenderCon_Click(object sender, EventArgs e)
        {
            if (txtCedulaCon.TextLength > 9 && txtNombreCon.TextLength > 0 && txtDineroCon.TextLength > 0)
            {
                double autos = 0;
                double con = 0;
                carropre = Convert.ToDouble(txtDineroCon.Text);
                if (carropre > preau)
                {
                    con = Convert.ToDouble(txtDineroCon.Text);
                    autos = con - preau;
                    lblCambio.Text = autos.ToString();
                    lblValorCon.Text = preau.ToString();
                    MessageBox.Show("Felicidades por su Compra", "Venta");
                    this.Hide();
                    Autos a = new Autos();
                    a.Visible = true;
                    RegistroVenta re = new RegistroVenta();
                    re.dgvRegistro.Rows.Add(rdbContado.Text, preau, txtNombreCon.Text, txtCedulaCon.Text);
                    re.Visible = true;


                }
                else
                {
                    MessageBox.Show("Dinero Insuficiente", "Vender");
                }
            }
            else
            {
                MessageBox.Show("LLene bien sus datos", "Datos");
            }

        }

        private void btnVenderPla_Click(object sender, EventArgs e)
        {
            if (txtNombrePla.TextLength>0&&txtCedulaPla.TextLength>9)
            {


                MessageBox.Show("Felicidades por su Compra", "Venta");
                this.Hide();
                Autos a = new Autos();
                a.Visible = true;
                RegistroVenta re = new RegistroVenta();
                re.dgvRegistro.Rows.Add(rdbPlasos.Text, preau, txtNombrePla.Text, txtCedulaPla.Text, lblValorPla.Text);
                re.Visible = true;
            }
            else
            {
                MessageBox.Show("LLene bien sus datos", "Datos");
            }

        }

        private void txtEntrada_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsNumber(letra) && letra != 8 && letra != 44)
            {
                e.Handled = true;
            }
        }

        private void txtNombrePla_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 32 && letra != 8)
            {
                e.Handled = true;
            }
        }

        private void txtCedulaPla_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsNumber(letra) && letra != 8)
            {
                e.Handled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Autos au = new Autos();
            au.Visible = true;
        }
    }
}
